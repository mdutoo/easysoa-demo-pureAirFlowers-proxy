============================================================================
OW2 FraSCAti Examples: HelloWorld OSGi
Copyright (C) 2010 INRIA, University of Lille 1

This library is free software; you can redistribute it and/or
modify it under the terms of the GNU Lesser General Public
License as published by the Free Software Foundation; either
version 2 of the License, or (at your option) any later version.

This library is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
Lesser General Public License for more details.

You should have received a copy of the GNU Lesser General Public
License along with this library; if not, write to the Free Software
Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA

Contact: frascati@ow2.org

Author: Philippe Merle

Contributor(s):
 
============================================================================

HelloWorld OSGi Example:
------------------------

This example shows how to embed existing OSGi bundles into an SCA application, i.e.,
use of <frascati:implementation.osgi bundle="..."/> implemented with Eclipse Equinox
and Apache Felix.

The directory 'bundles' contains three OSGi bundles (api, server, and client).
The directory 'sca' contains an SCA composite embedding the three OSGi bundles,
see sca/src/main/resources/helloworld-osgi.composite
The directory 'equinox' contains the pom.xml to run the SCA composite with Eclipse Equinox.
The directory 'felix' contains the pom.xml to run the SCA composite with Apache Felix.

Compilation with Maven:
-----------------------
  mvn install

Execution with Maven:
---------------------
  With Eclipse Equinox:
  cd equinox; mvn -Prun                      (standalone execution)
  cd equinox; mvn -Pexplorer                 (with FraSCAti Explorer)
  cd equinox; mvn -Pexplorer-fscript         (with FraSCAti Explorer and FScript plugin)
  cd equinox; mvn -Pfscript-console          (with FraSCAti FScript Console)
  cd equinox; mvn -Pfscript-console-explorer (with FraSCAti Explorer and FScript Console)
  cd equinox; mvn -Pexplorer-jdk6            (with FraSCAti Explorer and JDK6)

  With Apache Felix:
  cd felix; mvn -Prun                      (standalone execution)
  cd felix; mvn -Pexplorer                 (with FraSCAti Explorer)
  cd felix; mvn -Pexplorer-fscript         (with FraSCAti Explorer and FScript plugin)
  cd felix; mvn -Pfscript-console          (with FraSCAti FScript Console)
  cd felix; mvn -Pfscript-console-explorer (with FraSCAti Explorer and FScript Console)
  cd felix; mvn -Pexplorer-jdk6            (with FraSCAti Explorer and JDK6)

Execution with the FraSCAti script:
-----------------------------------
You have to compile this example with Maven.

TO BE COMPLETED
