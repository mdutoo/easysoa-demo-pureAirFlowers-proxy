package dsl;

public class Composite
{
	public static class Component {

		public String name;

		public Component()//String name)
		{
//			this.name = name;
		}

		public static class Property {
        			
			protected String name;

			public Property()//String name)
			{
//				this.name = name;
			}

			public void set(Object value)
			{
				System.out.println("set property '" + this.name + "'");
			}
		}
	}
	
	class Property {
		
		protected String name;

		public Property(String name)
		{
			this.name = name;
		}

		public void set(Object value)
		{
			System.out.println("set property '" + this.name + "'");
		}
	}
}
