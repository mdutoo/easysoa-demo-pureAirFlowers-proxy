package dsl;

class Essai
{
    public Composite composite = new Composite() {
    	public Component c1;
    };

    void operation()
	{
    	composite.c1 = null;
	}
}
