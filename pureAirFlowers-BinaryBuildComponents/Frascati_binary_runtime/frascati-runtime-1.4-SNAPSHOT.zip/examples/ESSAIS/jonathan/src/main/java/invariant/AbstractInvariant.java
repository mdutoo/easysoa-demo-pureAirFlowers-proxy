/**
 * OW2 FraSCAti Examples : ???
 * Copyright (C) 2011 INRIA, Univeristy of Lille 1
 *
 * This library is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Lesser General Public
 * License as published by the Free Software Foundation; either
 * version 2 of the License, or (at your option) any later version.
 *
 * This library is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 * Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public
 * License along with this library; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 *
 * Author: Philippe Merle
 *
 * Contributor(s):
 *
 */

package invariant;

import java.lang.reflect.Method;
import java.util.logging.Logger;

import org.objectweb.fractal.api.Component;
import org.objectweb.fractal.api.Interface;
import org.objectweb.fractal.api.control.ContentController;
import org.objectweb.fractal.api.control.LifeCycleController;
import org.objectweb.fractal.api.control.SuperController;
import org.objectweb.fractal.fraclet.annotations.Controller;
import org.objectweb.fractal.util.Fractal;

import org.osoa.sca.annotations.EagerInit;
import org.osoa.sca.annotations.Init;
import org.osoa.sca.annotations.Scope;

import org.ow2.frascati.tinfi.api.IntentHandler;
import org.ow2.frascati.tinfi.api.IntentJoinPoint;
import org.ow2.frascati.tinfi.api.control.SCAPropertyController;
import org.ow2.frascati.tinfi.api.control.SCABasicIntentController;

@Scope("COMPOSITE")
@EagerInit
public abstract class AbstractInvariant
{
    //---------------------------------------------------------------------------
    // Internal state.
    // --------------------------------------------------------------------------

    /**
     * Logger for this object.
     */
    protected Logger log = Logger.getLogger(this.getClass().getCanonicalName());

   /**
	 * Injection of the SuperController.
	 */
	@Controller("super-controller")
	public SuperController superController;

    //---------------------------------------------------------------------------
    // Internal methods.
    // --------------------------------------------------------------------------

    //---------------------------------------------------------------------------
    // Public methods.
    // --------------------------------------------------------------------------

	/**
	 * Initialization of the invariant component.
	 */
	@Init
	public final void scaComponentInit() throws Exception
	{
	  try {
	    declaration();
	  } catch(Exception e) {
	   	e.printStackTrace();
	   	throw e;
	  }
	}

	/**
	 * Declare invariants.
	 *
	 * Must be implemented by sub classes.
	 */
	public abstract void declaration() throws Exception;

	/**
	 * Declare a rule when a component's property is set.
	 *
	 * @param cname the name of the component.
	 * @param pname the name of the property.
	 * @param action the action to execute after the property 'pname' of the component 'cname' is set.
	 * @throws Exception when fails obscur.
	 */
	public final void whenPropertySet(String cname, final String pname, final Action<Void> action) throws Exception
	{
	  log.info("whenPropertySet(" + cname + ", " + pname + ")");

      // Obtain the component named cname.
	  Component component = getComponent(cname);

      // TODO: Check that the component 'cname' has a property 'pname'.

      //
      // Define the intent handler.
      //
      IntentHandler handler = new IntentHandler() {
        public Object invoke(IntentJoinPoint ijp) throws Throwable
        {
          // Proceed calls.
          Object result = ijp.proceed();
 
          // Execute the action after setting the property 'pname'.
          if(ijp.getArguments()[0].equals(pname)) {
            action.execute(null);
          }
 
          return result;
        }
      };

      //
      // Add the intent handler.
      //
      getIntentController(component).addFcIntentHandler(handler,
        SCAPropertyController.NAME, SCAPropertyController.class.getMethod("setValue", String.class, Object.class));
    }

	/**
	 * Declare a rule when a component is added.
	 *
	 * @param action the action to execute after a component is added.
	 * @throws Exception when fails obscur.
	 */
	public final void whenComponentAdded(final Action<Component> action) throws Exception
	{
      //
      // Declare the intent handler.
      //
      IntentHandler handler = new IntentHandler() {
        public Object invoke( IntentJoinPoint ijp ) throws Throwable
	    {
	      Object result = ijp.proceed();
	      action.execute((Component)(ijp.getArguments()[0]));
	      return result;
	    }
	  };
	 
      //
      // Add the intent handler.
	  //
      Component composite = getComposite();
      getIntentController(composite).addFcIntentHandler(handler,
        "content-controller", ContentController.class.getMethod("addFcSubComponent", Component.class));
    }

	/**
	 * Declare a rule when a component is removed.
	 *
	 * @param action the action to execute before a component is removed.
	 * @throws Exception when fails obscur.
	 */
	public final void whenComponentRemoved(final Action<Component> action) throws Exception
	{
      //
      // Declare the intent handler.
      //
      IntentHandler handler = new IntentHandler() {
        public Object invoke( IntentJoinPoint ijp ) throws Throwable
        {
          action.execute((Component)(ijp.getArguments()[0]));
          return ijp.proceed();
        }
      };

      //
      // Add the intent handler.
      //
      Component composite = getComposite();
      getIntentController(composite).addFcIntentHandler(handler,
        "content-controller", ContentController.class.getMethod("removeFcSubComponent", Component.class));
    }

	/**
	 * Get the enclosing composite.
	 *
	 * @return the enclosing composite.
	 */
	public final Component getComposite()
	{
      return superController.getFcSuperComponents()[0];
	}

	/**
	 * Get an enclosed component.
	 *
	 * @param cname the name of the enclosed component.
	 * @return the enclosed component.
	 * @throws Exception when fails obscur.
	 */
	public final Component getComponent(String cname) throws Exception
	{
      for(Component component : Fractal.getContentController(getComposite()).getFcSubComponents()) {
        if(cname.equals(Fractal.getNameController(component).getFcName())) {
          return component;
        }
      }
      throw new IllegalArgumentException("Invalid component name '" + cname + "'");
	}

	/**
	 * Get the intent controller of a component.
	 *
	 * @param c the given component.
	 * @return the intent controller of the given component.
	 * @throws Exception when fails obscur.
	 */
    public final SCABasicIntentController getIntentController(Component component) throws Exception
    {
      return (SCABasicIntentController)(component.getFcInterface(SCABasicIntentController.NAME));
    }

    /**
     * Stop a component.
     *
     * @param cname the name of the component.
	 * @throws Exception when fails obscur.
     */
	public void stopComponent(String cname) throws Exception
	{
		log.info("stopComponent(" + cname + ")");

		Component component = getComponent(cname);
        Fractal.getLifeCycleController(component).stopFc();
 	}

	/**
	 * Get the property controller of a component.
	 *
	 * @param c the given component.
	 * @return the property controller of the given component.
	 * @throws Exception when fails obscur.
	 */
    public final SCAPropertyController getPropertyController(Component component) throws Exception
    {
      return (SCAPropertyController)(component.getFcInterface(SCAPropertyController.NAME));
    }

    /**
     * Set a property of a component.
     *
     * @param cname the name of the component.
     * @param pname the name of the property.
     * @param value the value of the property.
	 * @throws Exception when fails obscur.
     */
    public final void setProperty(String cname, String pname, Object value) throws Exception
	{
   	    log.info("setProperty(" + cname + ", " + pname + ", " + value + ")");

   	    Component component = getComponent(cname);
	    SCAPropertyController pc = getPropertyController(component);
	    LifeCycleController lcc = Fractal.getLifeCycleController(component);
	    lcc.stopFc();
        pc.setType(pname, value.getClass());
	    pc.setValue(pname, value);
        lcc.startFc();
	}

    /**
     * Get a property of a component.
     *
     * @param cname the name of the component.
     * @param pname the name of the property.
     * @return the value of the property.
	 * @throws Exception when fails obscur.
     */
	public final int getPropertyAsInt(String cname, String pname) throws Exception
	{
		log.info("getPropertyAsInt(" + cname + ", " + pname + ")");

		Component component = getComponent(cname);
	    SCAPropertyController pc = getPropertyController(component);
		Integer propertyValue = (Integer)pc.getValue(pname);
		return propertyValue.intValue();
	}

    /**
     * Bind a reference to a service.
     *
     * @param source the source component.
     * @param reference the name of the reference.
     * @param target the target component.
     * @param service the name of the target service.
	 * @throws Exception when fails obscur.
     */
    public final void bind(Component source, String reference, String target, String service) throws Exception
    {
	  log.info("bind(..., " + reference + ", " + target + ", " + service + ")");

	  Object to = getComponent(target).getFcInterface(service);
      LifeCycleController lcc = Fractal.getLifeCycleController(source);
  	  lcc.stopFc();
  	  Fractal.getBindingController(source).bindFc(reference, to);
  	  lcc.startFc();
    }

    /**
     * Unbind a reference.
     *
     * @param component the component.
     * @param reference the name of the reference.
	 * @throws Exception when fails obscur.
     */
    public final void unbind(Component component, String reference) throws Exception
    {
  	  log.info("unbind(..., " + reference + ")");

      LifeCycleController lcc = Fractal.getLifeCycleController(component);
  	  lcc.stopFc();
  	  Fractal.getBindingController(component).unbindFc(reference);
  	  lcc.startFc();
    }

}
