/**
 * OW2 FraSCAti Examples : ???
 * Copyright (C) 2011 INRIA, University of Lille 1
 *
 * This library is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Lesser General Public
 * License as published by the Free Software Foundation; either
 * version 2 of the License, or (at your option) any later version.
 *
 * This library is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 * Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public
 * License along with this library; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 *
 * Author: Philippe Merle
 *
 * Contributor(s):
 *
 */

package example;

import org.osoa.sca.annotations.Scope;
import org.osoa.sca.annotations.Service;
import org.osoa.sca.annotations.Property;

/**
 * @author Philippe Merle - INRIA
 */
@Scope("COMPOSITE")
@Service(Runnable.class)
public class C1
  implements Runnable
{
    private int p1;

    @Property
    private void setP1(int v)
    {
      System.out.println("C1 - set p1 with " + v);
      p1 = v;
    }

    public final void run()
    {
      System.out.println("C1 - run with p1=" + p1);
    }
}
