/**
 * OW2 FraSCAti Examples : ???
 * Copyright (C) 2011 INRIA, University of Lille 1
 *
 * This library is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Lesser General Public
 * License as published by the Free Software Foundation; either
 * version 2 of the License, or (at your option) any later version.
 *
 * This library is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 * Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public
 * License along with this library; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 *
 * Author: Philippe Merle
 *
 * Contributor(s):
 *
 */

package example;

/**
 * Implementation of the architectural invariant of CC.
 */
public class InvariantCC
     extends invariant.AbstractInvariant
{
    public void declaration() throws Exception
    {
      // When the property 'p1' of the component 'c1' is set then
      whenPropertySet("c1", "p1",
        new invariant.Action<Void>() {
          public void execute(Void arg) throws Exception {
            // Get the value of the property.
            int v = getPropertyAsInt("c1", "p1");
            if(v < 4) {
              // If v < 4 then set the value of the property 'p2' of component 'c2'.
              setProperty("c2", "p2", v * 2);
    	    } else {
    	      // if v >= 4 then stop the component 'c2'.
    	      stopComponent("c2");
            }
          }
        }
      );
    }
}
