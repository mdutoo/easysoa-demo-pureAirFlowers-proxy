============================================================================
OW2 FraSCAti Examples: Factorial BPEL
Copyright (C) 2010 INRIA, University of Lille 1

This library is free software; you can redistribute it and/or
modify it under the terms of the GNU Lesser General Public
License as published by the Free Software Foundation; either
version 2 of the License, or (at your option) any later version.

This library is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
Lesser General Public License for more details.

You should have received a copy of the GNU Lesser General Public
License along with this library; if not, write to the Free Software
Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA

Contact: frascati@ow2.org

Author: Philippe Merle

Contributor(s):

============================================================================

Factorial BPEL:
---------------

This example illustrates a factorial service implemented as an SCA composite
containing a BPEL process and exposed as a Web Service and a REST resource.
This service computes factorial of given numbers.


Compilation with Maven:
-----------------------
  mvn install

Execution with Maven:
---------------------
  mvn -Prun                      (standalone execution)
  mvn -Pexplorer                 (with FraSCAti Explorer)
  mvn -Pexplorer-fscript         (with FraSCAti Explorer and FScript plugin)
  mvn -Pfscript-console          (with FraSCAti FScript Console)
  mvn -Pfscript-console-explorer (with FraSCAti Explorer and FScript Console)
  mvn -Pexplorer-jdk6            (with FraSCAti Explorer and JDK6)

Use the factorial service:
--------------------------
* Open a Web Service Explorer like soapUI or Eclipse Web Services Explorer tools
  and enter http://localhost:8090/ws/factorial?wsdl as URL to interact with 
  the factorial service as a SOAP Web Service.
* Open a Web Browser and enter http://localhost:8090/rest/factorial/5
  as URL to interact with the factorial service as a REST resource.
* http://localhost:8090/rest/factorial?_wadl to obtain the WADL associated
  to the factorial service.

Compilation and execution with the FraSCAti script:
---------------------------------------------------
TODO
